#ifdef __CLING__
#pragma link C++ class FourVector ;
#endif
